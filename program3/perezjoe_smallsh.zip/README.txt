When I was using the test script a.k.a p3testscript 2>&1
instead of outputting the script in the terminal
it would place it inside a file named '1'.

Also, running the test script locally will hang after the last test.
I'd advise to output the information into a file to see the results for the last test
without it hanging in the script if you wish.

I hope this is enough warning, have fun grading!
Thank you :)